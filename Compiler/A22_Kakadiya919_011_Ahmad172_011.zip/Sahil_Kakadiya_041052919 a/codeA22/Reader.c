/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Summer, 2023
* Author: Sahil Kakadiya
* Professors: Paulo Sousa
************************************************************
###################################################
#                                                 #
#    ALGONQUIN         @@@@@@@         COLLEGE    #
#                  @@-----------@@                #
#               @@@@|  S  V  P  |@@@@             #
#            @@@@@@@@-----------@@@@@@@@          #
#         @@@@@@@@@@@@@  @@@@@@@   @@@@@@@        #
#       @@@@@@@@@@@@@      @@@       @@@@@@       #
#     @@@@@@@    @@@@@    @@@@       @@@@@@@@     #
#    @@@@@@@       @@@@@ @@@@@@@    @@@@@@@@@@    #
#   @@@@@@@        @@@@@ @@@@@ @@@@@@    @@@@@@   #
#  @@@@@@@@@@    @@             @@@@      @@@@@@  #
#  @@@@@@@@@@@@@@@  @@@@@  @@@@  @@@@   @@    @@  #
# @@@@@@@@@@@@@@@   @@@@@ @@@@@   @@@@@@@@@    @@ #
# @@@@@      @@@@   @@@ @@@ @@@   @@@@    @@@@@@@ #
# @@@@        @@@@  @@@ @@@ @@@   @@@      @@@@@@ #
#  @@@@     @@@@@@@              @@@@@    @@@@@@  #
#  @@@@@@@@@@@     @@@  @@@   @@@    @@@@@@@@@@   #
#   @@@@@@@@@@@   @@@ @@@@@@ @@@@@    @@@@@@@@@   #
#    @@@@@@@@@@@@@@@ @@@@@@    @@@@@@@@@@@@@@@    #
#     @@@@@@@@@       @@@        @@@@@@@@@@@      #
#       @@@@@@         @@         @@@@@@@@@       #
#         @@@@@       @@@@@     @@@@@@@@@         #
#            @@@@@@@@@@@@@@@@@@@@@@@@@            #
#               @@@@@@@@@@@@@@@@@@@               #
#  COMPILERS        @@@@@@@@@@@        2023-S     #
#                                                 #
###################################################
*/

/*
***********************************************************
* File name: Reader.c
* Compiler: MS Visual Studio 2022
* Course: CST 8152 � Compilers, Lab Section: [011, 012, 013]
* Assignment: A12.
* Date: May 01 2023
* Professor: Paulo Sousa
* Purpose: This file is the main code for Buffer/Reader (A12)
************************************************************
*/

/*
 *.............................................................................
 * MAIN ADVICE:
 * - Please check the "TODO" labels to develop your activity.
 * - Review the functions to use "Defensive Programming".
 *.............................................................................
 */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef READER_H_
#include "Reader.h"
#endif

/*
***********************************************************
* Function name: readerCreate
* Purpose: Creates the buffer reader according to capacity, increment
	factor and operational mode ('f', 'a', 'm')
* Author: Svillen Ranev / Paulo Sousa
* History/Versions: S22
* Called functions: calloc(), malloc()
* Parameters:
*   size = initial capacity
*   increment = increment factor
*   mode = operational mode
* Return value: bPointer (pointer to reader)
* Algorithm: Allocation of memory according to inicial (default) values.
* TODO ......................................................
*	- Adjust datatypes for your LANGUAGE.
*   - Use defensive programming
*	- Check boundary conditions
*	- Check flags.
*************************************************************
*/

ReaderPointer readerCreate(svp_intger size, svp_intger increment, svp_intger mode) {
	ReaderPointer readerPointer;
	/* TO_DO: Defensive programming */
	/* TO_DO: Adjust the values according to parameters */
	readerPointer = (ReaderPointer)calloc(1, sizeof(BufferReader));
	if (!readerPointer){
		return NULL;
	}

	if(size <= 0) {
		free(readerPointer);
		return NULL;
	}
		
	if (!readerPointer->content) {
		free(readerPointer);
		return NULL;
	}

	/* TO_DO: Defensive programming */
	/* TO_DO: Initialize the histogram */\
	for (int i = 0; i < HISTOGRAM_SIZE; i++) {
    	readerPointer->histogram[i] = 0;
	}

	readerPointer->size = size;
	readerPointer->increment = increment;
	readerPointer->mode = mode;

	/* TO_DO: Initialize flags */
	readerPointer->flags = 0;

	/* TO_DO: The created flag must be signalized as EMP */
	readerPointer->flags |= CREATED_EMP_FLAG;
	
	/* NEW: Cleaning the content */
	if (readerPointer->content)
		readerPointer->content[0] = READER_TERMINATOR;
	readerPointer->offset.wrte = 0;
	readerPointer->offset.mark = 0;
	readerPointer->offset.read = 0;
	return readerPointer;
}


/*
***********************************************************
* Function name: readerAddChar
* Purpose: Adds a char to buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   ch = char to be added
* Return value:
*	readerPointer (pointer to Buffer Reader)
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/

ReaderPointer readerAddChar(ReaderPointer const readerPointer, svp_char ch) {
	svp_string tempReader = NULL;
	svp_intger newSize = 0;
	/* TO_DO: Defensive programming */
	/* TO_DO: Reset Realocation */
	/* TO_DO: Test the inclusion of chars */
	if (readerPointer->offset.wrte * (svp_intger)sizeof(svp_char) < readerPointer->size) {
		/* TO_DO: This buffer is NOT full */
		printf("Buffer is not full. Continuing to add characters.\n");
	} 
	else {
    /* TO_DO: Reset Full flag */
    readerPointer->flags &= ~FULL_FLAG;  // Assuming a FULL_FLAG is used

    switch (readerPointer->mode) {
        case MODE_FIXED:
            return NULL;
        case MODE_ADDIT:
            /* TO_DO: Adjust new size */
            newSize = readerPointer->size + increment;  // Adjust the size based on your requirements

            /* TO_DO: Defensive programming */
            if (newSize <= readerPointer->size) {
                // Handle invalid size adjustment appropriately (e.g., log error, return NULL)
                return NULL;
            }

            tempReader = (svp_string)realloc(readerPointer->content, newSize);  // Reallocate memory with adjusted size
            if (!tempReader) {
                // Handle reallocation failure appropriately (e.g., log error, clean up resources, return NULL)
                return NULL;
            }

            readerPointer->content = tempReader;  // Update the content pointer
            readerPointer->size = newSize;  // Update the size
            break;
        case MODE_MULTI:
            /* TO_DO: Adjust new size */
            newSize = readerPointer->size * multiplier;  // Adjust the size based on your requirements

            /* TO_DO: Defensive programming */
            if (newSize <= readerPointer->size) {
                // Handle invalid size adjustment appropriately (e.g., log error, return NULL)
                return NULL;
            }

            tempReader = (svp_string)realloc(readerPointer->content, newSize);  // Reallocate memory with adjusted size
            if (!tempReader) {
                // Handle reallocation failure appropriately (e.g., log error, clean up resources, return NULL)
                return NULL;
            }

            readerPointer->content = tempReader;  // Update the content pointer
            readerPointer->size = newSize;  // Update the size
            break;
        default:
            return NULL;
    }

    /* TO_DO: New reader allocation */
    ReaderPointer newReaderPointer = (ReaderPointer)calloc(1, sizeof(BufferReader));
    if (!newReaderPointer) {
        // Handle allocation failure appropriately (e.g., log error, clean up resources, return NULL)
        return NULL;
    }

    // Copy necessary members from the existing readerPointer to the newReaderPointer
    newReaderPointer->size = readerPointer->size;
    newReaderPointer->increment = readerPointer->increment;
    newReaderPointer->mode = readerPointer->mode;
    // Copy other members as needed

    /* TO_DO: Defensive programming */

    /* TO_DO: Check Relocation */
    if (readerPointer->content != newReaderPointer->content) {
        // Relocation occurred, handle it accordingly (e.g., update pointers, cleanup, etc.)
    }

		// Free the old readerPointer as necessary
		free(readerPointer);

		// Return the newReaderPointer or perform additional operations if needed
		return newReaderPointer;
	}
	/* TO_DO: Add the char */
	if (readerPointer->content != NULL && readerPointer->offset.wrte < readerPointer->size) {
    readerPointer->content[readerPointer->offset.wrte++] = ch;

    /* TO_DO: Updates histogram */
    int index = (int)ch;  // Assuming the histogram index corresponds to the character value
    if (index >= 0 && index < HISTOGRAM_SIZE) {
        readerPointer->histogram[index]++;
    }
	} else {
		// Handle invalid content or offset appropriately (e.g., log error, return NULL)
		return NULL;
	}

	return readerPointer;
}

/*
***********************************************************
* Function name: readerClear
* Purpose: Clears the buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerClear(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Adjust flags original */
    readerPointer->flags &= ~ORIGINAL_FLAGS;  // Adjust the flags based on your requirements

    readerPointer->offset.wrte = 0;
    readerPointer->offset.mark = 0;
    readerPointer->offset.read = 0;

    return svp_TRUE;
}

/*
***********************************************************
* Function name: readerFree
* Purpose: Releases the buffer address
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerFree(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Free pointers */
    free(readerPointer->content);  // Assuming content is a dynamically allocated pointer
    free(readerPointer);  // Free the readerPointer itself

    return svp_TRUE;
}

/*
***********************************************************
* Function name: readerIsFull
* Purpose: Checks if buffer reader is full
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerIsFull(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Check flag if buffer is FUL */
    if (readerPointer->flags & FULL_FLAG) {
        return svp_TRUE;
    } else {
        return svp_FALSE;
    }
}


/*
***********************************************************
* Function name: readerIsEmpty
* Purpose: Checks if buffer reader is empty.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerIsEmpty(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Check flag if buffer is EMP */
    if (readerPointer->flags & EMP_FLAG) {
        return svp_TRUE;
    } else {
        return svp_FALSE;
    }
}

/*
***********************************************************
* Function name: readerSetMark
* Purpose: Adjust the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   mark = mark position for char
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerSetMark(ReaderPointer const readerPointer, svp_intger mark) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Adjust mark */
    if (mark < 0) {
        // Handle invalid mark value appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    readerPointer->offset.mark = mark;

    return svp_TRUE;
}


/*
***********************************************************
* Function name: readerPrint
* Purpose: Prints the string in the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Number of chars printed.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerPrint(ReaderPointer const readerPointer) {
    svp_intger cont = 0;
    svp_char c;
    
    /* TO_DO: Defensive programming (including invalid chars) */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Check flag if buffer EOB has achieved */
    while (cont < readerPointer->offset.wrte) {
        c = readerGetChar(readerPointer);

        if (c == EOB_CHAR) {
            break;  // EOB flag reached, exit the loop
        }

        cont++;
        printf("%c", c);
    }

    return cont;
}

/*
***********************************************************
* Function name: readerLoad
* Purpose: Loads the string in the buffer with the content of
	an specific file.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   fileDescriptor = pointer to file descriptor
* Return value:
*	Number of chars read and put in buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerLoad(ReaderPointer const readerPointer, FILE* const fileDescriptor) {
    svp_intger size = 0;
    svp_char c;
    
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL || fileDescriptor == NULL) {
        // Handle invalid readerPointer or fileDescriptor appropriately (e.g., log error, return appropriate value)
        return READER_ERROR;
    }

    c = (svp_char)fgetc(fileDescriptor);
    while (!feof(fileDescriptor)) {
        if (!readerAddChar(readerPointer, c)) {
            ungetc(c, fileDescriptor);
            return READER_ERROR;
        }
        c = (char)fgetc(fileDescriptor);
        size++;
    }

    /* TO_DO: Defensive programming */
    if (ferror(fileDescriptor)) {
        // Handle file error appropriately (e.g., log error, return appropriate value)
        return READER_ERROR;
    }
    
    return size;
}

/*
***********************************************************
* Function name: readerRecover
* Purpose: Rewinds the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRecover(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Recover positions */
    readerPointer->offset.read = 0;

    return svp_TRUE;
}

/*
***********************************************************
* Function name: readerRetract
* Purpose: Retracts the buffer to put back the char in buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRetract(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Retract (return 1 pos read) */
    if (readerPointer->offset.read > 0) {
        readerPointer->offset.read--;
    }

    return svp_TRUE;
}


/*
***********************************************************
* Function name: readerRestore
* Purpose: Resets the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRestore(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return svp_FALSE;
    }

    /* TO_DO: Restore positions (read/mark) */
    readerPointer->offset.read = readerPointer->offset.mark;

    return svp_TRUE;
}


/*
***********************************************************
* Function name: readerGetChar
* Purpose: Returns the char in the getC position.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Char in the getC position.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_char readerGetChar(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL || readerPointer->content == NULL) {
        // Handle invalid readerPointer or content pointer appropriately (e.g., log error, return appropriate value)
        return READER_TERMINATOR;
    }

    /* TO_DO: Check condition to read/wrte */
    if (readerPointer->offset.read >= readerPointer->offset.wrte) {
        /* TO_DO: Set EOB flag */
        readerPointer->flags |= EOB_FLAG;
        return READER_TERMINATOR;
    }

    /* TO_DO: Reset EOB flag */
    readerPointer->flags &= ~EOB_FLAG;

    return readerPointer->content[readerPointer->offset.read++];
}


/*
***********************************************************
* Function name: readerGetContent
* Purpose: Returns the pointer to String.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   pos = position to get the pointer
* Return value:
*	Position of string char.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_string readerGetContent(ReaderPointer const readerPointer, svp_intger pos) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL || readerPointer->content == NULL || pos < 0 || pos >= readerPointer->offset.wrte) {
        // Handle invalid readerPointer, content pointer, or position appropriately (e.g., log error, return appropriate value)
        return NULL;
    }

    /* TO_DO: Return content (string) */
    return readerPointer->content + pos;
}



/*
***********************************************************
* Function name: readerGetPosRead
* Purpose: Returns the value of getCPosition.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	The read position offset.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetPosRead(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return read */
    return readerPointer->offset.read;
}

/*
***********************************************************
* Function name: readerGetPosWrte
* Purpose: Returns the position of char to be added
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Write position
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetPosWrte(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return wrte */
    return readerPointer->offset.wrte;
}


/*
***********************************************************
* Function name: readerGetPosMark
* Purpose: Returns the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Mark position.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetPosMark(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return mark */
    return readerPointer->offset.mark;
}

/*
***********************************************************
* Function name: readerGetSize
* Purpose: Returns the current buffer capacity
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Size of buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetSize(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return size */
    return readerPointer->size;
}

/*
***********************************************************
* Function name: readerGetInc
* Purpose: Returns the buffer increment.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	The Buffer increment.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetInc(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return increment */
    return readerPointer->increment;
}

/*
***********************************************************
* Function name: readerGetMode
* Purpose: Returns the operational mode
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Operational mode.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerGetMode(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Return mode */
    return readerPointer->mode;
}


/*
***********************************************************
* Function name: readerGetFlags
* Purpose: Returns the entire flags of Buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Flags from Buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_byte readerGetFlags(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return 0;
    }

    /* TO_DO: Return flags */
    return readerPointer->flags;
}



/*
***********************************************************
* Function name: readerPrintStat
* Purpose: Shows the char statistic.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value: (Void)
* TO_DO:
*   - Use defensive programming
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_void readerPrintStat(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	 if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return;
    }

    /* TO_DO: Print the histogram */
    printf("Histogram:\n");
    printf("----------\n");
}

/*
***********************************************************
* Function name: readerNumErrors
* Purpose: Returns the number of errors found.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Number of errors.
* TO_DO:
*   - Use defensive programming
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intger readerNumErrors(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    if (readerPointer == NULL) {
        // Handle invalid readerPointer appropriately (e.g., log error, return appropriate value)
        return -1;
    }

    /* TO_DO: Returns the number of errors */
    return readerPointer->numErrors;
}
