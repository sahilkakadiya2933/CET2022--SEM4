/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Summer, 2023
* Author: Sahil Kakadiya and Sajid Ahmad
* Professors: Paulo Sousa
************************************************************
###################################################
#                                                 #
#    ALGONQUIN         @@@@@@@         COLLEGE    #
#                  @@-----------@@                #
#               @@@@|  S  V  P  |@@@@             #
#            @@@@@@@@-----------@@@@@@@@          #
#         @@@@@@@@@@@@@  @@@@@@@   @@@@@@@        #
#       @@@@@@@@@@@@@      @@@       @@@@@@       #
#     @@@@@@@    @@@@@    @@@@       @@@@@@@@     #
#    @@@@@@@       @@@@@ @@@@@@@    @@@@@@@@@@    #
#   @@@@@@@        @@@@@ @@@@@ @@@@@@    @@@@@@   #
#  @@@@@@@@@@    @@             @@@@      @@@@@@  #
#  @@@@@@@@@@@@@@@  @@@@@  @@@@  @@@@   @@    @@  #
# @@@@@@@@@@@@@@@   @@@@@ @@@@@   @@@@@@@@@    @@ #
# @@@@@      @@@@   @@@ @@@ @@@   @@@@    @@@@@@@ #
# @@@@        @@@@  @@@ @@@ @@@   @@@      @@@@@@ #
#  @@@@     @@@@@@@              @@@@@    @@@@@@  #
#  @@@@@@@@@@@     @@@  @@@   @@@    @@@@@@@@@@   #
#   @@@@@@@@@@@   @@@ @@@@@@ @@@@@    @@@@@@@@@   #
#    @@@@@@@@@@@@@@@ @@@@@@    @@@@@@@@@@@@@@@    #
#     @@@@@@@@@       @@@        @@@@@@@@@@@      #
#       @@@@@@         @@         @@@@@@@@@       #
#         @@@@@       @@@@@     @@@@@@@@@         #
#            @@@@@@@@@@@@@@@@@@@@@@@@@            #
#               @@@@@@@@@@@@@@@@@@@               #
#  COMPILERS        @@@@@@@@@@@        2023-S     #
#                                                 #
###################################################
*/

/*
***********************************************************
* File name: Reader.c
* Compiler: MS Visual Studio 2022
* Course: CST 8152 � Compilers, Lab Section: [011, 012, 013]
* Assignment: A12.
* Date: May 01 2023
* Professor: Paulo Sousa
* Purpose: This file is the main code for Buffer/Reader (A12)
************************************************************
*/

/*
 *.............................................................................
 * MAIN ADVICE:
 * - Please check the "TODO" labels to develop your activity.
 * - Review the functions to use "Defensive Programming".
 *.............................................................................
 */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef READER_H_
#include "Reader.h"
#endif

 /*
 ************************************************************
 * Error printing function with variable number of arguments
 * Params: Variable arguments, using formats from C language.
 *	- Internal vars use list of arguments and types from stdarg.h
 *   - NOTE: The format is using signature from C Language
 ************************************************************
 */

svp_void bErrorPrint(svp_string fmt, ...) {
	/* Initialize variable list */
	va_list ap;
	va_start(ap, fmt);

	(svp_void)vfprintf(stderr, fmt, ap);
	va_end(ap);

	/* Move to new line */
	if (strchr(fmt, '\n') == NULL)
		fprintf(stderr, "\n");
}

/*
***********************************************************
* Function name: readerCreate
* Purpose: Creates the buffer reader according to capacity, increment
	factor and operational mode ('f', 'a', 'm')
* Author: Svillen Ranev / Paulo Sousa
* History/Versions: S22
* Called functions: calloc(), malloc()
* Parameters:
*   size = initial capacity
*   increment = increment factor
*   mode = operational mode
* Return value: bPointer (pointer to reader)
* Algorithm: Allocation of memory according to inicial (default) values.
* TODO ......................................................
*	- Adjust datatypes for your LANGUAGE.
*   - Use defensive programming
*	- Check boundary conditions
*	- Check flags.
*************************************************************
*/

ReaderPointer readerCreate(svp_intg size, svp_intg increment, svp_intg mode) {
	ReaderPointer readerPointer;
	/* TO_DO: Defensive programming */
	/* TO_DO: Adjust the values according to parameters */
	printf("%d %d %d\n", size, increment, mode);
	if (size <= 0)
	{
		size = READER_DEFAULT_SIZE;
		
	}
	
	if (increment <= 0)
	{
		increment = READER_DEFAULT_INCREMENT;
	}
	if (mode != MODE_ADDIT && mode != MODE_MULTI)
	{
		mode = MODE_FIXED;
	}
	
	

	
	
	
	readerPointer = (ReaderPointer)calloc(1, sizeof(BufferReader));
	if (!readerPointer)
		return NULL;
	readerPointer->content = (svp_string)malloc(size);
	/* TO_DO: Defensive programming */
	if (readerPointer->content == NULL)
	{
		return NULL;
	}
	/* TO_DO: Initialize the histogram */
	for (int i = 0; i < NCHAR; i++)
	{
		readerPointer->histogram[i]=0;
	}
	readerPointer->size = size;
	readerPointer->increment = increment;
	readerPointer->mode = mode;
	/* TO_DO: Initialize flags */
	/* TO_DO: The created flag must be signalized as EMP */
	readerPointer->flags = READER_DEFAULT_FLAG;
	return readerPointer;
}


/*
***********************************************************
* Function name: readerAddChar
* Purpose: Adds a char to buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   ch = char to be added
* Return value:
*	readerPointer (pointer to Buffer Reader)
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/

ReaderPointer readerAddChar(ReaderPointer const readerPointer, svp_char ch) {
	if (ch >= NCHAR || ch<0) {
		printf("\n*** Error: %d ***\n", ch);
		readerPointer->numReaderErrors++;
		return readerPointer;
	}
	else {
		//printf("%c", ch);
	}
	svp_string tempReader = NULL;
	svp_intg newSize = 0;
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Reset Realocation */
	/* TO_DO: Test the inclusion of chars */
	if (readerPointer->offset.wrte * (svp_intg)sizeof(svp_char) < readerPointer->size) {
		/* TO_DO: This buffer is NOT full */
		readerPointer->flags = readerPointer->flags & ~FUL;
	} else {
		/* TO_DO: Reset Full flag */
		readerPointer->flags = readerPointer->flags | FUL;
		switch (readerPointer->mode) {
		case MODE_FIXED:
			return NULL;
		case MODE_ADDIT:
			/* TO_DO: Adjust new size */
			newSize = readerPointer->size + readerPointer->increment* (svp_intg)sizeof(svp_char);
			/* TO_DO: Defensive programming */
			if (newSize < readerPointer->size)
			{
				return NULL;
			}
			break;
		case MODE_MULTI:
			/* TO_DO: Adjust new size */
			newSize = readerPointer->size * readerPointer->increment;
			/* TO_DO: Defensive programming */

			if (newSize < readerPointer->size)
			{
				return NULL;
			}
			
			break;
		default:
			return NULL;
		}
		/* TO_DO: New reader allocation */
		tempReader = realloc(readerPointer->content, newSize);

		/* TO_DO: Defensive programming */
		/* TO_DO: Check Relocation */
		if (tempReader == NULL)
		{
			return NULL;
		}
		else {
			readerPointer->content = tempReader;
			readerPointer->size = newSize;
			readerPointer->flags = readerPointer->flags | REL;
			readerPointer->flags = readerPointer->flags & ~FUL;
		}
		
		 
	}
	/* TO_DO: Add the char */
	
	
		readerPointer->content[readerPointer->offset.wrte++] = ch;
		readerPointer->flags = readerPointer->flags & ~EMP;
		/* TO_DO: Updates histogram */
		readerPointer->histogram[ch]++;
	
	
	
	return readerPointer;
}

/*
***********************************************************
* Function name: readerClear
* Purpose: Clears the buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerClear(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Adjust flags original */
	readerPointer->flags = READER_DEFAULT_FLAG;
	readerPointer->offset.mark = 0;
	readerPointer->offset.read = 0;
	readerPointer->offset.wrte = 0;

	return svp_TRUE;
}

/*
***********************************************************
* Function name: readerFree
* Purpose: Releases the buffer address
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerFree(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Free pointers */
	if (readerPointer->content!=NULL)
	{
		free(readerPointer->content);
		readerPointer->content = NULL;
		return svp_TRUE;
	}
	else {
		return svp_FALSE;
	}
	
}

/*
***********************************************************
* Function name: readerIsFull
* Purpose: Checks if buffer reader is full
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerIsFull(ReaderPointer const readerPointer) {
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);
		/* TO_DO: Check flag if buffer is FUL */
		
	}
	return readerPointer->flags & FUL;
	
}


/*
***********************************************************
* Function name: readerIsEmpty
* Purpose: Checks if buffer reader is empty.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerIsEmpty(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);
		
	}
	/* TO_DO: Check flag if buffer is EMP */
	return readerPointer->flags & EMP;

	
}

/*
***********************************************************
* Function name: readerSetMark
* Purpose: Adjust the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   mark = mark position for char
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerSetMark(ReaderPointer const readerPointer, svp_intg mark) {
	printf("mark: %d\n", mark);
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Adjust mark */
	if (mark >= 0 && mark <= readerGetPosRead(readerPointer))
	{
		readerPointer->offset.mark = mark;
		return svp_TRUE;
	}
	else {
		return svp_FALSE;
	}
	
}


/*
***********************************************************
* Function name: readerPrint
* Purpose: Prints the string in the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Number of chars printed.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerPrint(ReaderPointer const readerPointer) {
	svp_intg cont = 0;
	svp_char c;
	/* TO_DO: Defensive programming (including invalid chars) */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	c = readerGetChar(readerPointer);
	/* TO_DO: Check flag if buffer EOB has achieved */
	while (cont < readerPointer->offset.wrte) {
		if (readerPointer->flags & END)
		{
			break;
		}
		cont++;
		printf("%c", c);
		c = readerGetChar(readerPointer);

	}
	return cont;
}

/*
***********************************************************
* Function name: readerLoad
* Purpose: Loads the string in the buffer with the content of
	an specific file.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   fileDescriptor = pointer to file descriptor
* Return value:
*	Number of chars read and put in buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerLoad(ReaderPointer const readerPointer, FILE* const fileDescriptor) {
	svp_intg size = 0;
	svp_char c;
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	c = (svp_char)fgetc(fileDescriptor);
	while (!feof(fileDescriptor)) {
		if (!readerAddChar(readerPointer, c)) {
			ungetc(c, fileDescriptor);
			return READER_ERROR;
		}
		c = (char)fgetc(fileDescriptor);
		size++;
	}
	/* TO_DO: Defensive programming */
	if (size < 0)
	{
		bErrorPrint("%s", "bufferSize is less than 0");
		exit(EXIT_FAILURE);
		
	}
	return size;
}


/*
***********************************************************
* Function name: readerRecover
* Purpose: Rewinds the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRecover(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Recover positions */
	readerPointer->offset.read = 0;
	readerPointer->offset.mark = 0;
	return svp_TRUE;
}


/*
***********************************************************
* Function name: readerRetract
* Purpose: Retracts the buffer to put back the char in buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRetract(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Retract (return 1 pos read) */
	if (readerPointer->offset.read > 0)
	{
		readerPointer->offset.read--;
		return svp_TRUE;
	}
	else {
		return svp_FALSE;
	}
	
}


/*
***********************************************************
* Function name: readerRestore
* Purpose: Resets the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_boln readerRestore(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Restore positions (read/mark) */
	readerPointer->offset.read = readerPointer->offset.mark;
	return svp_TRUE;
}


/*
***********************************************************
* Function name: readerGetChar
* Purpose: Returns the char in the getC position.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Char in the getC position.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_char readerGetChar(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Check condition to read/wrte */
	if (readerGetPosRead(readerPointer) >= readerGetPosWrte(readerPointer))
	{
		/* TO_DO: Set EOB flag */
		readerPointer->flags = readerPointer->flags | END;
		
		return 0;
	}
	else {
		/* TO_DO: Reset EOB flag */

		readerPointer->flags = readerPointer->flags & ~END;
		return readerPointer->content[readerPointer->offset.read++];
	}
	}
	
	


/*
***********************************************************
* Function name: readerGetContent
* Purpose: Returns the pointer to String.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   pos = position to get the pointer
* Return value:
*	Position of string char.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_string readerGetContent(ReaderPointer const readerPointer, svp_intg pos) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return content (string) */
	return &readerPointer->content[pos];
}



/*
***********************************************************
* Function name: readerGetPosRead
* Purpose: Returns the value of getCPosition.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	The read position offset.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetPosRead(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return read */
	return readerPointer ->offset.read;
}


/*
***********************************************************
* Function name: readerGetPosWrte
* Purpose: Returns the position of char to be added
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Write position
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetPosWrte(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return wrte */
	return readerPointer->offset.wrte;
}


/*
***********************************************************
* Function name: readerGetPosMark
* Purpose: Returns the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Mark position.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetPosMark(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return mark */
	return readerPointer->offset.mark;
}


/*
***********************************************************
* Function name: readerGetSize
* Purpose: Returns the current buffer capacity
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Size of buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetSize(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return size */
	return readerPointer->size;

}

/*
***********************************************************
* Function name: readerGetInc
* Purpose: Returns the buffer increment.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	The Buffer increment.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetInc(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return increment */
	return readerPointer->increment;
}

/*
***********************************************************
* Function name: readerGetMode
* Purpose: Returns the operational mode
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Operational mode.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerGetMode(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return mode */
	return readerPointer->mode;
}


/*
***********************************************************
* Function name: readerGetFlags
* Purpose: Returns the entire flags of Buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Flags from Buffer.
* TO_DO:
*   - Use defensive programming
*	- Check boundary conditions
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_byte readerGetFlags(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Return flags */
	return readerPointer->flags;
}



/*
***********************************************************
* Function name: readerPrintStat
* Purpose: Shows the char statistic.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value: (Void)
* TO_DO:
*   - Use defensive programming
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_void readerPrintStat(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Print the histogram */
	for (int i = 0; i < NCHAR; i++)
	{
		printf("%d: %d\n", i,readerPointer->histogram[i]);
	}
}

/*
***********************************************************
* Function name: readerNumErrors
* Purpose: Returns the number of errors found.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*	Number of errors.
* TO_DO:
*   - Use defensive programming
*	- Adjust for your LANGUAGE.
*************************************************************
*/
svp_intg readerNumErrors(ReaderPointer const readerPointer) {
	/* TO_DO: Defensive programming */
	if (readerPointer == NULL)
	{
		bErrorPrint("%s", "readerPointer is null");
		exit(EXIT_FAILURE);

	}
	/* TO_DO: Returns the number of errors */
	return readerPointer->numReaderErrors;
}
