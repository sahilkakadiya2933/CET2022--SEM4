﻿
/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Spring, 2023
* Author: TO_DO
* Professors: Paulo Sousa
************************************************************

###################################################
#                                                 #
#    ALGONQUIN         @@@@@@@         COLLEGE    #
#                  @@-----------@@                #
#               @@@@|  M O L D  |@@@@             #
#            @@@@@@@@-----------@@@@@@@@          #
#         @@@@@@@@@@@@@  @@@@@@@   @@@@@@@        #
#       @@@@@@@@@@@@@      @@@       @@@@@@       #
#     @@@@@@@    @@@@@    @@@@       @@@@@@@@     #
#    @@@@@@@       @@@@@ @@@@@@@    @@@@@@@@@@    #
#   @@@@@@@        @@@@@ @@@@@ @@@@@@    @@@@@@   #
#  @@@@@@@@@@    @@             @@@@      @@@@@@  #
#  @@@@@@@@@@@@@@@  @@@@@  @@@@  @@@@   @@    @@  #
# @@@@@@@@@@@@@@@   @@@@@ @@@@@   @@@@@@@@@    @@ #
# @@@@@      @@@@   @@@ @@@ @@@   @@@@    @@@@@@@ #
# @@@@        @@@@  @@@ @@@ @@@   @@@      @@@@@@ #
#  @@@@     @@@@@@@              @@@@@    @@@@@@  #
#  @@@@@@@@@@@     @@@  @@@   @@@    @@@@@@@@@@   #
#   @@@@@@@@@@@   @@@ @@@@@@ @@@@@    @@@@@@@@@   #
#    @@@@@@@@@@@@@@@ @@@@@@    @@@@@@@@@@@@@@@    #
#     @@@@@@@@@       @@@        @@@@@@@@@@@      #
#       @@@@@@         @@         @@@@@@@@@       #
#         @@@@@       @@@@@     @@@@@@@@@         #
#            @@@@@@@@@@@@@@@@@@@@@@@@@            #
#               @@@@@@@@@@@@@@@@@@@               #
#  COMPILERS        @@@@@@@@@@@        2023-S     #
#                                                 #
###################################################

*/

/*
************************************************************
* File name: Parser.c
* Compiler: MS Visual Studio 2022
* Course: CST 8152 – Compilers, Lab Section: [011, 012, 013]
* Assignment: A32.
* Date: Sep 01 2022
* Purpose: This file contains all functionalities from Parser.
* Function list: (...).
************************************************************
*/

/* TO_DO: Adjust the function header */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef PARSER_H_
#include "Parser.h"
#endif

/* Parser data */
extern ParserData psData; /* BNF statistics */

/*
************************************************************
 * Process Parser
 ***********************************************************
 */
/* TO_DO: This is the function to start the parser - check your program definition */

svp_void startParser() {
	/* TO_DO: Initialize Parser data */
	svp_intg i = 0;
	for (i = 0; i < NUM_BNF_RULES; i++) {
		psData.parsHistogram[i] = 0;
	}
	/* Proceed parser */
	lookahead = tokenizer();
	if (lookahead.code != SEOF_T) {
		program();
	}
	matchToken(SEOF_T, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Source file parsed");
}


/*
 ************************************************************
 * Match Token
 ***********************************************************
 */
/* TO_DO: This is the main code for match - check your definition */
svp_void matchToken(svp_intg tokenCode, svp_intg tokenAttribute) {
	svp_intg matchFlag = 1;
	printf("matchtoken: tokencode: %d lookahead: %d\n",tokenCode,lookahead.code);
	switch (lookahead.code) {
	case KW_T:
		printf("CodeType: %d TokenAttribute: %d \n", lookahead.attribute.codeType,tokenAttribute);
		if (tokenAttribute!=ANY_ATTR&&lookahead.attribute.codeType != tokenAttribute)
			matchFlag = 0;
	default:
		if (lookahead.code != tokenCode)
			matchFlag = 0;
	}
	if (matchFlag && lookahead.code == SEOF_T)
		return;
	if (matchFlag) {
		lookahead = tokenizer();
		if (lookahead.code == ERR_T) {
			printError();
			lookahead = tokenizer();
			syntaxErrorNumber++;
		}
	}
	else
		syncErrorHandler(tokenCode);
}

/*
 ************************************************************
 * Syncronize Error Handler
 ***********************************************************
 */
/* TO_DO: This is the function to handler error - adjust basically datatypes */
svp_void syncErrorHandler(svp_intg syncTokenCode) {
	printError();
	syntaxErrorNumber++;
	while (lookahead.code != syncTokenCode) {
		if (lookahead.code == SEOF_T)
			exit(syntaxErrorNumber);
		lookahead = tokenizer();
	}
	if (lookahead.code != SEOF_T)
		lookahead = tokenizer();
}

/*
 ************************************************************
 * Print Error
 ***********************************************************
 */
/* TO_DO: This is the function to error printing - adjust basically datatypes */
svp_void printError() {
	extern numParserErrors;			/* link to number of errors (defined in Parser.h) */
	Token t = lookahead;
	printf("%s%s%3d\n", STR_LANGNAME, ": Syntax error:  Line:", line);
	printf("*****  Token code:%3d Attribute: ", t.code);
	switch (t.code) {
	case ERR_T:
		printf("*ERROR*: %s\n", t.attribute.errLexeme);
		break;
	case SEOF_T:
		printf("SEOF_T\t\t%d\t\n", t.attribute.seofType);
		break;
	case MNID_T:
		printf("MNID_T:\t\t%s\t\n", t.attribute.idLexeme);
		break;
	case STR_T:
		printf("STR_T: %s\n", readerGetContent(stringLiteralTable, t.attribute.contentString));
		break;
	case KW_T:
		printf("KW_T: %s\n", keywordTable[t.attribute.codeType]);
		break;
	case LPR_T:
		printf("LPR_T\n");
		break;
	case RPR_T:
		printf("RPR_T\n");
		break;
	case LBR_T:
		printf("LBR_T\n");
		break;
	case RBR_T:
		printf("RBR_T\n");
		break;
	case EOS_T:
		printf("NA\n");
		break;
	default:
		printf("%s%s%d\n", STR_LANGNAME, ": Scanner error: invalid token code: ", t.code);
		numParserErrors++; // Updated parser error
	}
}

/*
 ************************************************************
 * Program statement
 * BNF: <program> -> main& { <opt_statements> }
 * FIRST(<program>)= {MNID_T (main&)}.
 ***********************************************************
 */
svp_void program() {
	/* Update program statistics */
	psData.parsHistogram[BNF_program]++;
	/* Program code */
	switch (lookahead.code) {
	case CMT_T:
		comment();
		program();
		break;
	case MNID_T:
		if (strncmp(lookahead.attribute.idLexeme, LANG_MAIN, 5) == 0) {
			matchToken(MNID_T, NO_ATTR);
			matchToken(LBR_T, NO_ATTR);
			dataSession();
			codeSession();
			matchToken(RBR_T, NO_ATTR);
			break;
		}
		else {
			printError();
		}
		break;
	case KW_T:
		if (lookahead.attribute.codeType == KW_fn)
		{
			matchToken(KW_T, KW_fn);
			functionDefinition();

		}

		;
		break;
	case SEOF_T:
		; // Empty
		break;
	default:
		printError();
	}
	printf("%s%s\n", STR_LANGNAME, ": Program parsed");
}

/*
 ************************************************************
 * comment
 * BNF: comment
 * FIRST(<comment>)= {CMT_T}.
 ***********************************************************
 */
svp_void comment() {
	psData.parsHistogram[BNF_comment]++;
	matchToken(CMT_T, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Comment parsed");
}

/*
 ************************************************************
 * dataSession
 * BNF: <dataSession> -> data { <opt_varlist_declarations> }
 * FIRST(<program>)= {KW_T (KW_data)}.
 ***********************************************************
 */
svp_void dataSession() {
	psData.parsHistogram[BNF_dataSession]++;
	switch (lookahead.code) {
	case CMT_T:
		comment();
	default:
		//matchToken(KW_T, KW_data);
		//matchToken(LBR_T, NO_ATTR);
		optVarListDeclarations();
		//matchToken(RBR_T, NO_ATTR);
		printf("%s%s\n", STR_LANGNAME, ": Data Session parsed");
	}
}


svp_void functionDefinition() {
	psData.parsHistogram[BNF_dataSession]++;
	switch (lookahead.code) {
	case CMT_T:
		comment();
	
   
	default:
		matchToken(MNID_T, NO_ATTR);
		matchToken(LPR_T, NO_ATTR);
		matchToken(RPR_T, NO_ATTR);
		//matchToken(KW_T, KW_data);
		matchToken(LBR_T, NO_ATTR);
		optVarListDeclarations();
		codeSession();
		matchToken(RBR_T, NO_ATTR);
		printf("%s%s\n", STR_LANGNAME, ": Function definition parsed");
	}
}
svp_void functionCall()
{
	matchToken(MNID_T, NO_ATTR);
	matchToken(LPR_T, NO_ATTR);
	value();
	matchToken(RPR_T, NO_ATTR);
}
svp_void typedValue()
{
	matchToken(KW_T, ANY_ATTR);
	matchToken(LPR_T, NO_ATTR);
	value();
	matchToken(RPR_T, NO_ATTR);
}
svp_void value()
{
	int matched =0;
	switch (lookahead.code)
	{
	case LPR_T:
		matchToken(LPR_T, NO_ATTR);
		value();
		matchToken(RPR_T, NO_ATTR);
		matched = 1;
		break;
	case STR_T:
		matchToken(STR_T, NO_ATTR);
		matched = 1;
		break;
	case INL_T:
		matchToken(INL_T, NO_ATTR);
		matched = 1;
		break;
	case FL_T:
		matchToken(FL_T, NO_ATTR);
		matched = 1;
		break;
	case VID_T:
		matchToken(VID_T, NO_ATTR);
		matched = 1;
		break;
	
	case MNID_T:
		functionCall();
		matched = 1;
		break;
	case OP_LOG:
		if (lookahead.attribute.logicalOperator == OP_NOT)
		{
			matchToken(OP_LOG, NO_ATTR);
			value();
			
		}
		break;
	case OP_MATH:
		if (lookahead.attribute.logicalOperator == OP_ADD|| lookahead.attribute.logicalOperator == OP_SUB)
		{
			matchToken(OP_MATH, NO_ATTR);
			value();

		}
		break;
	case KW_T:
		if (lookahead.attribute.codeType == KW_i64 || lookahead.attribute.codeType == KW_f64 || lookahead.attribute.codeType == KW_String)
		{
			typedValue();
			matched = 1;
		}
		break;
	}
	
	if (matched && lookahead.code == OP_MATH)
	{
		matchToken(OP_MATH, NO_ATTR);
		value();
	}
	else if (matched && lookahead.code == OP_REL)
	{
		matchToken(OP_REL,NO_ATTR);
		value();
	}
	else if (matched && lookahead.code == OP_LOG)
	{
		matchToken(OP_LOG, NO_ATTR);
		value();
	}
	
	
}
svp_void type()
{
	printf("type\n");
	if (lookahead.code == KW_T)
	{
		switch (lookahead.attribute.codeType)
		{
		case KW_String:
			matchToken(KW_T,KW_String);
			break;
		case KW_i64:
			matchToken(KW_T, KW_i64);
			break;
		case KW_f64:
			matchToken(KW_T, KW_f64);
			break;
		}
	}
	
}
svp_void variableDeclaration() {
	psData.parsHistogram[BNF_dataSession]++;
	printf("variable dec\n");
	matchToken(VID_T, NO_ATTR);
	matchToken(OP_TYPE, NO_ATTR);
	type();
	
	if (lookahead.code == OP_ASM)
	{
		matchToken(OP_ASM, NO_ATTR);
		value();

	}
	matchToken(EOS_T, NO_ATTR);
	
	/*
	switch (lookahead.code) {
	case CMT_T:
		comment();
		variableDeclaration();
		break;


	case KW_T:
		if (lookahead.attribute.codeType == KW_let)
		{
			matchToken(KW_T, KW_let);
			matchToken(VID_T, NO_ATTR);
			
		}*/
		printf("%s%s\n", STR_LANGNAME, ": Variable definition parsed");
	}

/*
 ************************************************************
 * Optional Var List Declarations
 * BNF: <opt_varlist_declarations> -> <varlist_declarations> | e
 * FIRST(<opt_varlist_declarations>) = { e, KW_T (KW_int), KW_T (KW_real), KW_T (KW_string)}.
 ***********************************************************
 */
svp_void optVarListDeclarations() {
	psData.parsHistogram[BNF_optVarListDeclarations]++;
	printf("########optvarlist\n");
	switch (lookahead.code) {
	case CMT_T:
		comment();

	default:
		if (lookahead.attribute.codeType == KW_let)
		{
			printf("FOund let\n");
			matchToken(KW_T, KW_let);
			variableDeclaration();
			optVarListDeclarations();

		}
	}
	printf("%s%s\n", STR_LANGNAME, ": Optional Variable List Declarations parsed");
}

/*
 ************************************************************
 * codeSession statement
 * BNF: <codeSession> -> code { <opt_statements> }
 * FIRST(<codeSession>)= {KW_T (KW_code)}.
 ***********************************************************
 */
svp_void codeSession() {
	printf("--------code session\n");
	psData.parsHistogram[BNF_codeSession]++;
	switch (lookahead.code) {
	case CMT_T:
		comment();
		codeSession();
		break;
	default:
		//matchToken(KW_T, KW_code);
		//matchToken(LBR_T, NO_ATTR);
		optionalStatements();
		//matchToken(RBR_T, NO_ATTR);
		printf("%s%s\n", STR_LANGNAME, ": Code Session parsed");
	}
}

/* TO_DO: Continue the development (all non-terminal functions) */

/*
 ************************************************************
 * Optional statement
 * BNF: <opt_statements> -> <statements> | ϵ
 * FIRST(<opt_statements>) = { ϵ , IVID_T, FVID_T, SVID_T, KW_T(KW_if),
 *				KW_T(KW_while), MNID_T(print&), MNID_T(input&) }
 ***********************************************************
 */
svp_void optionalStatements() {
	printf("--------Optional statements\n");
	char c;
	//scanf("%c", &c);
	psData.parsHistogram[BNF_optionalStatements]++;
	switch (lookahead.code) {
	case CMT_T:
		comment();
		optionalStatements();
		break;
	case VID_T:
		printf("Optional statements VID_T\n");
		matchToken(VID_T, NO_ATTR);
		matchToken(OP_ASM, NO_ATTR);
		value();
		matchToken(EOS_T, NO_ATTR);
		optionalStatements();
		break;

	case MNID_T:
		/*if ((strncmp(lookahead.attribute.idLexeme, LANG_WRTE, 6) == 0) ||
			(strncmp(lookahead.attribute.idLexeme, LANG_READ, 6) == 0)) {
			statements();
			break;
		}*/
		functionCall();
		matchToken(EOS_T, NO_ATTR);
		optionalStatements();
		break;
	case KW_T:
		switch (lookahead.attribute.codeType)
		{
		case KW_while:
			matchToken(KW_T, KW_while);
			value();
			matchToken(LBR_T, NO_ATTR);
			optVarListDeclarations();
			codeSession();
			matchToken(RBR_T, NO_ATTR);
			break;
		case KW_if:
			matchToken(KW_T, KW_if);
			value();
			matchToken(LBR_T, NO_ATTR);
			optVarListDeclarations();
			codeSession();
			matchToken(RBR_T, NO_ATTR);
			break;
		case KW_else:
			matchToken(KW_T, KW_else);
			if (lookahead.code == LBR_T)
			{
				matchToken(LBR_T, NO_ATTR);
				optVarListDeclarations();
				codeSession();
				matchToken(RBR_T, NO_ATTR);
				
			}
			else {
				optionalStatements();
			}
			break;
			
			
		}

		optionalStatements();
		break;

	default:
		; 
	}
	printf("%s%s\n", STR_LANGNAME, ": Optional statements parsed");
}

/*
 ************************************************************
 * Statements
 * BNF: <statements> -> <statement><statementsPrime>
 * FIRST(<statements>) = { IVID_T, FVID_T, SVID_T, KW_T(KW_if),
 *		KW_T(KW_while), MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
svp_void statements() {
	psData.parsHistogram[BNF_statements]++;
	statement();
	statementsPrime();
	printf("%s%s\n", STR_LANGNAME, ": Statements parsed");
}

/*
 ************************************************************
 * Statements Prime
 * BNF: <statementsPrime> -> <statement><statementsPrime> | ϵ
 * FIRST(<statementsPrime>) = { ϵ , IVID_T, FVID_T, SVID_T, 
 *		KW_T(KW_if), KW_T(KW_while), MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
svp_void statementsPrime() {
	psData.parsHistogram[BNF_statementsPrime]++;
	switch (lookahead.code) {
	case MNID_T:
		if (strncmp(lookahead.attribute.idLexeme, LANG_WRTE, 6) == 0) {
			statements();
			break;
		}
	default:
		; //empty string
	}
}

/*
 ************************************************************
 * Single statement
 * BNF: <statement> -> <assignment statement> | <selection statement> |
 *	<iteration statement> | <input statement> | <output statement>
 * FIRST(<statement>) = { IVID_T, FVID_T, SVID_T, KW_T(KW_if), KW_T(KW_while),
 *			MNID_T(input&), MNID_T(print&) }
 ***********************************************************
 */
svp_void statement() {
	psData.parsHistogram[BNF_statement]++;
	switch (lookahead.code) {
	case KW_T:
		switch (lookahead.attribute.codeType) {
		default:
			printError();
		}
		break;
	case MNID_T:
		if (strncmp(lookahead.attribute.idLexeme, LANG_WRTE, 6) == 0) {
			outputStatement();
		}
		break;
	default:
		printError();
	}
	printf("%s%s\n", STR_LANGNAME, ": Statement parsed");
}

/*
 ************************************************************
 * Output Statement
 * BNF: <output statement> -> print& (<output statementPrime>);
 * FIRST(<output statement>) = { MNID_T(print&) }
 ***********************************************************
 */
svp_void outputStatement() {
	psData.parsHistogram[BNF_outputStatement]++;
	printf("OUTPUT STATEMENT\n");
	matchToken(MNID_T, NO_ATTR);
	matchToken(LPR_T, NO_ATTR);
	outputVariableList();
	matchToken(RPR_T, NO_ATTR);
	matchToken(EOS_T, NO_ATTR);
	printf("%s%s\n", STR_LANGNAME, ": Output statement parsed");
}

/*
 ************************************************************
 * Output Variable List
 * BNF: <opt_variable list> -> <variable list> | ϵ
 * FIRST(<opt_variable_list>) = { IVID_T, FVID_T, SVID_T, ϵ }
 ***********************************************************
 */
svp_void outputVariableList() {
	psData.parsHistogram[BNF_outputVariableList]++;
	switch (lookahead.code) {
	case STR_T:
		matchToken(STR_T, NO_ATTR);
		break;
	default:
		value();
		
	}
	printf("%s%s\n", STR_LANGNAME, ": Output variable list parsed");
}

/*
 ************************************************************
 * The function prints statistics of BNF rules
 * Param:
 *	- Parser data
 * Return:
 *	- Void (procedure)
 ***********************************************************
 */
/*
svp_void printBNFData(ParserData psData) {
}
*/
svp_void printBNFData(ParserData psData) {
	/* Print Parser statistics */
	printf("Statistics:\n");
	printf("----------------------------------\n");
	int cont = 0;
	for (cont = 0; cont < NUM_BNF_RULES; cont++) {
		if (psData.parsHistogram[cont] > 0)
			printf("%s%s%s%d%s", "Token[", BNFStrTable[cont], "]=", psData.parsHistogram[cont], "\n");
	}
	printf("----------------------------------\n");
}
