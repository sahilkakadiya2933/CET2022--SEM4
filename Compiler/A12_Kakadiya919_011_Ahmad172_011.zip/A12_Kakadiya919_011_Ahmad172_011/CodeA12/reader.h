/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Summer, 2023
* Author: Sahil Kakadiya and Sajid Ahmad
* Professors: Paulo Sousa
************************************************************
###################################################
#                                                 #
#    ALGONQUIN         @@@@@@@         COLLEGE    #
#                  @@-----------@@                #
#               @@@@|  S  V  P  |@@@@             #
#            @@@@@@@@-----------@@@@@@@@          #
#         @@@@@@@@@@@@@  @@@@@@@   @@@@@@@        #
#       @@@@@@@@@@@@@      @@@       @@@@@@       #
#     @@@@@@@    @@@@@    @@@@       @@@@@@@@     #
#    @@@@@@@       @@@@@ @@@@@@@    @@@@@@@@@@    #
#   @@@@@@@        @@@@@ @@@@@ @@@@@@    @@@@@@   #
#  @@@@@@@@@@    @@             @@@@      @@@@@@  #
#  @@@@@@@@@@@@@@@  @@@@@  @@@@  @@@@   @@    @@  #
# @@@@@@@@@@@@@@@   @@@@@ @@@@@   @@@@@@@@@    @@ #
# @@@@@      @@@@   @@@ @@@ @@@   @@@@    @@@@@@@ #
# @@@@        @@@@  @@@ @@@ @@@   @@@      @@@@@@ #
#  @@@@     @@@@@@@              @@@@@    @@@@@@  #
#  @@@@@@@@@@@     @@@  @@@   @@@    @@@@@@@@@@   #
#   @@@@@@@@@@@   @@@ @@@@@@ @@@@@    @@@@@@@@@   #
#    @@@@@@@@@@@@@@@ @@@@@@    @@@@@@@@@@@@@@@    #
#     @@@@@@@@@       @@@        @@@@@@@@@@@      #
#       @@@@@@         @@         @@@@@@@@@       #
#         @@@@@       @@@@@     @@@@@@@@@         #
#            @@@@@@@@@@@@@@@@@@@@@@@@@            #
#               @@@@@@@@@@@@@@@@@@@               #
#  COMPILERS        @@@@@@@@@@@        2023-S     #
#                                                 #
###################################################
*/

/*
************************************************************
* File name: Reader.h
* Compiler: MS Visual Studio 2022
* Course: CST 8152   Compilers, Lab Section: [011, 012]
* Assignment: A12.
* Date: May 01 2023
* Professor: Paulo Sousa
* Purpose: This file is the main header for Reader (.h)
************************************************************
*/

/*
 *.............................................................................
 * MAIN ADVICE:
 * Please check the "TODO" labels to develop your activity.
 *.............................................................................
 */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef READER_H_
#define READER_H_

/* TIP: Do not change pragmas, unless necessary .......................................*/
/*#pragma warning(1:4001) *//*to enforce C89 type comments  - to make //comments an warning */
/*#pragma warning(error:4001)*//* to enforce C89 comments - to make // comments an error */

/* standard header files */
#include <stdio.h>  /* standard input/output */
#include <malloc.h> /* for dynamic memory allocation*/
#include <limits.h> /* implementation-defined data type ranges and limits */

/* CONSTANTS DEFINITION: GENERAL (NOT LANGUAGE DEPENDENT) .................................. */

/* Modes (used to create buffer reader) */
enum READER_MODE {
    MODE_FIXED = 'F', /* Fixed mode (constant size) */
    MODE_ADDIT = 'A', /* Additive mode (constant increment to be added) */
    MODE_MULTI = 'M'  /* Multiplicative mode (constant increment to be multiplied) */
};

/* Constants about controls (not need to change) */
#define READER_ERROR        (-1)                        /* General error message */
#define READER_TERMINATOR   '\0'                            /* General EOF */

/* CONSTANTS DEFINITION: PREFIXED BY LANGUAGE NAME (SOFIA) .................................. */

/* You should add your own constant definitions here */
#define READER_MAX_SIZE INT_MAX-1   /* maximum capacity */ 

#define READER_DEFAULT_SIZE         250     /* default initial buffer reader capacity */
#define READER_DEFAULT_INCREMENT    10      /* default increment factor */

/* Add your bit-masks constant definitions here - Defined for BOA */
/* BITS                                (7654.3210) */
#define READER_DEFAULT_FLAG 0x00    /* (0000.0000)_2 = (000)_10 */
/* TO_DO: BIT 3: FUL = Full */
/* TO_DO: BIT 2: EMP: Empty */
/* TO_DO: BIT 1: REL = Relocation */
/* TO_DO: BIT 0: END = EndOfBuffer */

#define FUL 0x08; // Binary: 0000 1000 (Bit 3)
#define EMP 0x04; // Binary: 0000 0100 (Bit 2)
#define REL 0x02; // Binary: 0000 0010 (Bit 1)
#define END 0x01; // Binary: 0000 0001 (Bit 0)

#define SET 0x40; // Binary: 0100 0000 (Bit 6)
#define RST 0x20; // Binary: 0010 0000 (Bit 5)
#define CHK 0x10; // Binary: 0001 0000 (Bit 4)



#define NCHAR               128         /* Chars from 0 to 127 */

#define CHARSEOF            (-1)       /* EOF Code for Reader */

/* STRUCTURES DEFINITION: SUFIXED BY LANGUAGE NAME (SOFIA) .................................. */

/* TODO: Adjust datatypes */

/* Offset declaration */
typedef struct offset {
    SVP_Integer mark;         /* the offset to the mark position (in chars) */
    SVP_Integer read;         /* the offset to the get a char position (in chars) */
    SVP_Integer wrte;         /* the offset to the add chars (in chars) */
} Offset;

/* Buffer structure */
typedef struct bufferReader {
    SVP_String content;            /* pointer to the beginning of character array (character buffer) */
    SVP_Integer   size;               /* current dynamic memory size (in bytes) allocated to character buffer */
    SVP_Integer   increment;          /* character array increment factor */
    SVP_Integer   mode;               /* operational mode indicator */
    SVP_byte   flags; 
    SVP_Integer mark; /* contains character array reallocation flag and end-of-buffer flag */
    Offset      offset;             /* Offset / position field */
    SVP_Integer   histogram[NCHAR];   /* Statistics of chars */
    SVP_Integer   numReaderErrors;    /* Number of errors from Reader */
} BufferReader, * ReaderPointer;

/* FUNCTIONS DECLARATION:  .................................. */
/* General Operations */
ReaderPointer   readerCreate        (SVP_Integer, SVP_Integer, SVP_Integer);
ReaderPointer   readerAddChar       (ReaderPointer const, SVP_char);
SVP_boln       readerClear         (ReaderPointer const);
SVP_boln       readerFree          (ReaderPointer const);
SVP_boln       readerIsFull        (ReaderPointer const);
SVP_boln       readerIsEmpty       (ReaderPointer const);
SVP_boln       readerSetMark       (ReaderPointer const, SVP_Integer);
SVP_Integer       readerPrint         (ReaderPointer const);
SVP_Integer       readerLoad          (ReaderPointer const, FILE* const);
SVP_boln       readerRecover       (ReaderPointer const);
SVP_boln       readerRetract       (ReaderPointer const);
SVP_boln       readerRestore       (ReaderPointer const);
/* Getters */
SVP_char       readerGetChar       (ReaderPointer const);
SVP_String     readerGetContent    (ReaderPointer const, SVP_Integer);
SVP_Integer       readerGetPosRead    (ReaderPointer const);
SVP_Integer       readerGetPosWrte    (ReaderPointer const);
SVP_Integer       readerGetPosMark    (ReaderPointer const);
SVP_Integer       readerGetSize       (ReaderPointer const);
SVP_Integer       readerGetInc        (ReaderPointer const);
SVP_Integer       readerGetMode       (ReaderPointer const);
SVP_byte       readerGetFlags      (ReaderPointer const);
SVP_void       readerPrintStat     (ReaderPointer const);
SVP_Integer       readerNumErrors     (ReaderPointer const);

#endif


