# SVP Example 1:
  The program is "lexically" correct
  and should not generate any error #
fn main() { 
 
 println!(“Hello, World!”);
}
