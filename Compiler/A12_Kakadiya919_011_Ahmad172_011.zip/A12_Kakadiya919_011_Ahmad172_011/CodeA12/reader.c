/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Summer, 2023
* Author: Sahil Kakadiya and Sajid Ahmad
* Professors: Paulo Sousa
************************************************************
###################################################
#                                                 #
#    ALGONQUIN         @@@@@@@         COLLEGE    #
#                  @@-----------@@                #
#               @@@@|  S  V  P  |@@@@             #
#            @@@@@@@@-----------@@@@@@@@          #
#         @@@@@@@@@@@@@  @@@@@@@   @@@@@@@        #
#       @@@@@@@@@@@@@      @@@       @@@@@@       #
#     @@@@@@@    @@@@@    @@@@       @@@@@@@@     #
#    @@@@@@@       @@@@@ @@@@@@@    @@@@@@@@@@    #
#   @@@@@@@        @@@@@ @@@@@ @@@@@@    @@@@@@   #
#  @@@@@@@@@@    @@             @@@@      @@@@@@  #
#  @@@@@@@@@@@@@@@  @@@@@  @@@@  @@@@   @@    @@  #
# @@@@@@@@@@@@@@@   @@@@@ @@@@@   @@@@@@@@@    @@ #
# @@@@@      @@@@   @@@ @@@ @@@   @@@@    @@@@@@@ #
# @@@@        @@@@  @@@ @@@ @@@   @@@      @@@@@@ #
#  @@@@     @@@@@@@              @@@@@    @@@@@@  #
#  @@@@@@@@@@@     @@@  @@@   @@@    @@@@@@@@@@   #
#   @@@@@@@@@@@   @@@ @@@@@@ @@@@@    @@@@@@@@@   #
#    @@@@@@@@@@@@@@@ @@@@@@    @@@@@@@@@@@@@@@    #
#     @@@@@@@@@       @@@        @@@@@@@@@@@      #
#       @@@@@@         @@         @@@@@@@@@       #
#         @@@@@       @@@@@     @@@@@@@@@         #
#            @@@@@@@@@@@@@@@@@@@@@@@@@            #
#               @@@@@@@@@@@@@@@@@@@               #
#  COMPILERS        @@@@@@@@@@@        2023-S     #
#                                                 #
###################################################
*/

/*
***********************************************************
* File name: Reader.c
* Compiler: MS Visual Studio 2022
* Course: CST 8152   Compilers, Lab Section: [011, 012, 013]
* Assignment: A12.
* Date: May 01 2023
* Professor: Paulo Sousa
* Purpose: This file is the main code for Buffer/Reader (A12)
************************************************************
*/

/*
 *.............................................................................
 * MAIN ADVICE:
 * - Please check the "TODO" labels to develop your activity.
 * - Review the functions to use "Defensive Programming".
 *.............................................................................
 */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef READER_H_
#include "Reader.h"
#endif

/*
***********************************************************
* Function name: readerCreate
* Purpose: Creates the buffer reader according to capacity, increment
    factor and operational mode ('f', 'a', 'm')
* Author: Svillen Ranev / Paulo Sousa
* History/Versions: S22
* Called functions: calloc(), malloc()
* Parameters:
*   size = initial capacity
*   increment = increment factor
*   mode = operational mode
* Return value: bPointer (pointer to reader)
* Algorithm: Allocation of memory according to inicial (default) values.
* TODO ......................................................
*   - Adjust datatypes for your LANGUAGE.
*   - Use defensive programming
*   - Check boundary conditions
*   - Check flags.
*************************************************************
*/
SVP_Integer histogram_size;

ReaderPointer readerCreate(SVP_Integer size, SVP_Integer increment, SVP_Integer mode) {
    ReaderPointer readerPointer;
    /* TO_DO: Defensive programming */
	
    /* TO_DO: Adjust the values according to parameters */
    size = READER_DEFAULT_SIZE;
    increment = READER_DEFAULT_INCREMENT;
    mode = MODE_FIXED;
    if (size <= 0) {
        return size;
    }
    if (increment <= 0) {
        return increment;
    } 
    if(!mode==(MODE_ADDIT && MODE_MULTI)) {
        return mode;
    }
    readerPointer = (ReaderPointer)calloc(1, sizeof(BufferReader));
    if (!readerPointer)
        return NULL;
    readerPointer->content = (SVP_String)malloc(size);
    /* TO_DO: Defensive programming */
    /* TO_DO: Initialize the histogram */
    if ((readerPointer->content)==NULL) {
        return NULL;
    }
	readerPointer->size = size;
    readerPointer->increment = increment;
    readerPointer->mode = mode;
    /* TO_DO: Initialize flags */
    /* TO_DO: The created flag must be signalized as EMP */
    readerPointer->flags = READER_DEFAULT_FLAG;
    for (int i = 0; i < NCHAR; i++) {
        readerPointer->histogram[i] = 0;
    }
    readerPointer->numReaderErrors = 0;

    histogram_size = NCHAR;
	return readerPointer;
}

/*
***********************************************************
* Function name: readerAddChar
* Purpose: Adds a char to buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   ch = char to be added
* Return value:
*   readerPointer (pointer to Buffer Reader)
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/

ReaderPointer readerAddChar(ReaderPointer const readerPointer, SVP_char ch) {

    if (ch >= NCHAR) {
        readerPointer->numReaderErrors++;
        return readerPointer;
    }

    SVP_String tempReader = NULL;
    SVP_Integer newSize = 0;
    /* TO_DO: Defensive programming */
    /* TO_DO: Reset Realocation */
    /* TO_DO: Test the inclusion of chars */
   

	if (readerPointer->offset.wrte * (SVP_Integer)sizeof(SVP_char) < readerPointer->size) {
        /* TO_DO: This buffer is NOT full */
        readerPointer->flags = FUL;
    } else {
        /* TO_DO: Reset Full flag */
		readerPointer->flags = RST;

        switch (readerPointer->mode) {
        case MODE_FIXED:
            return NULL;
        case MODE_ADDIT:
            /* TO_DO: Adjust new size */
			newSize = readerPointer->size + readerPointer->increment;
            /* TO_DO: Defensive programming */
            break;
        case MODE_MULTI:
            /* TO_DO: Adjust new size */
			newSize = readerPointer->size * readerPointer->increment;
            /* TO_DO: Defensive programming */
            break;
        default:
            return NULL;
        }
        /* TO_DO: New reader allocation */
        /* TO_DO: Defensive programming */
        /* TO_DO: Check Relocation */
		 if (!tempReader) {
            return NULL;
        }

        readerPointer->content = tempReader;
        readerPointer->size = newSize;
    }
    /* TO_DO: Add the char */
    readerPointer->content[readerPointer->offset.wrte++] = ch;
    /* TO_DO: Updates histogram */
    return readerPointer;
}

/*
***********************************************************
* Function name: readerClear
* Purpose: Clears the buffer reader
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerClear(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Adjust flags original */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Reset flags to their original states, assuming you have some predefined default state.
    readerPointer->flags = READER_DEFAULT_FLAG;  // Assuming DEFAULT_FLAG is defined somewhere in your code.

    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerFree
* Purpose: Releases the buffer address
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerFree(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Free pointers */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Free the content first
    free(readerPointer->content);
    // Then free the ReaderPointer itself
    free(readerPointer);

    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerIsFull
* Purpose: Checks if buffer reader is full
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerIsFull(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Check flag if buffer is FUL */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Check if buffer is full based on your flag value.
    if (readerPointer->flags == 0x08) { // Assuming FULL is defined somewhere in your code.
        return SVP_TRUE;
    }

    return SVP_FALSE;
}

/*
***********************************************************
* Function name: readerIsEmpty
* Purpose: Checks if buffer reader is empty.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerIsEmpty(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Check flag if buffer is EMP */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Check if buffer is empty based on your flag value.
    if (readerPointer->flags == 0x04) { // Assuming EMP is defined somewhere in your code.
        return SVP_TRUE;
    }

    return SVP_FALSE;
}

/*
***********************************************************
* Function name: readerSetMark
* Purpose: Adjust the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   mark = mark position for char
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerSetMark(ReaderPointer const readerPointer, SVP_Integer mark) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Adjust mark */
	 if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Adjust the mark. Please note that the specifics of this operation would depend on your codebase.
    readerPointer->mark = mark;

    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerPrint
* Purpose: Prints the string in the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Number of chars printed.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerPrint(ReaderPointer const readerPointer) {
    SVP_Integer cont = 0;
    SVP_char c;
    /* TO_DO: Defensive programming (including invalid chars) */
     if (readerPointer == NULL) {
        return -1;
    }

	c = readerGetChar(readerPointer);
    /* TO_DO: Check flag if buffer EOB has achieved */
    while (cont < readerPointer->offset.wrte) {
		
        printf("%c", c);
        c = readerGetChar(readerPointer);
		cont++;
    }
    return cont;
}

/*
***********************************************************
* Function name: readerLoad
* Purpose: Loads the string in the buffer with the content of
    an specific file.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   fileDescriptor = pointer to file descriptor
* Return value:
*   Number of chars read and put in buffer.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerLoad(ReaderPointer const readerPointer, FILE* const fileDescriptor) {
    SVP_Integer size = 0;
    SVP_char c;
    /* TO_DO: Defensive programming */
	if (readerPointer == NULL || fileDescriptor == NULL) {
        return READER_ERROR;
    }
    c = (SVP_char)fgetc(fileDescriptor);
    while (!feof(fileDescriptor)) {
        if (!readerAddChar(readerPointer, c)) {
            ungetc(c, fileDescriptor);
            return READER_ERROR;
        }
        c = (char)fgetc(fileDescriptor);
        size++;
    }
    /* TO_DO: Defensive programming */
    return size;
}

/*
***********************************************************
* Function name: readerRecover
* Purpose: Rewinds the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerRecover(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Recover positions */
	if (readerPointer == NULL) {
	    return SVP_FALSE;
    }

    // Recover positions. Please note that the specifics of this operation would depend on your codebase.
    readerPointer->offset.read = readerPointer->mark; 

    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerRetract
* Purpose: Retracts the buffer to put back the char in buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerRetract(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Retract (return 1 pos read) */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Retract read position by one
    if (readerPointer->offset.read > 0) {
        readerPointer->offset.read--;
    }

    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerRestore
* Purpose: Resets the buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Boolean value about operation success
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_boln readerRestore(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Restore positions (read/mark) */
	if (readerPointer == NULL) {
        return SVP_FALSE;
    }

    // Restore read and mark positions. 
    // The specifics of this operation would depend on your codebase.
    readerPointer->offset.read = readerPointer->mark;
    return SVP_TRUE;
}

/*
***********************************************************
* Function name: readerGetChar
* Purpose: Returns the char in the getC position.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Char in the getC position.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_char readerGetChar(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Check condition to read/wrte */
    /* TO_DO: Set EOB flag */
    /* TO_DO: Reset EOB flag */
	if (readerPointer == NULL) {
        return '\0';
    }

    // Check condition to read/write
    if (readerPointer->offset.read >= readerPointer->offset.wrte) {
        return '\0';
    }

    // Set EOB flag
    readerPointer->flags = 0x01;

    return readerPointer->content[readerPointer->offset.read++];
}

/*
***********************************************************
* Function name: readerGetContent
* Purpose: Returns the pointer to String.
* Parameters:
*   readerPointer = pointer to Buffer Reader
*   pos = position to get the pointer
* Return value:
*   Position of string char.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_String readerGetContent(ReaderPointer const readerPointer, SVP_Integer pos) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return content (string) */
    if (readerPointer == NULL || pos < 0 || pos >= readerPointer->offset.wrte) {
        return NULL;
    }

    // Return content (string) at given position
    return &readerPointer->content[pos];
}


/*
***********************************************************
* Function name: readerGetPosRead
* Purpose: Returns the value of getCPosition.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   The read position offset.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetPosRead(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return read */
     if (readerPointer == NULL) {
        return -1;
    }

    // Return read position
    return readerPointer->offset.read;
}

/*
***********************************************************
* Function name: readerGetPosWrte
* Purpose: Returns the position of char to be added
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Write position
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetPosWrte(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return wrte */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return write position
    return readerPointer->offset.wrte;
}

/*
***********************************************************
* Function name: readerGetPosMark
* Purpose: Returns the position of mark in the buffer
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Mark position.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetPosMark(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return mark */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return mark position
    return readerPointer->mark;
}

/*
***********************************************************
* Function name: readerGetSize
* Purpose: Returns the current buffer capacity
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Size of buffer.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetSize(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return size */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return size
    return readerPointer->size;
}

/*
***********************************************************
* Function name: readerGetInc
* Purpose: Returns the buffer increment.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   The Buffer increment.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetInc(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return increment */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return increment. Please note that the specifics of this operation would depend on your codebase.
    return readerPointer->increment;
}

/*
***********************************************************
* Function name: readerGetMode
* Purpose: Returns the operational mode
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Operational mode.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerGetMode(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return mode */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return mode
    return readerPointer->mode;
}


/*
***********************************************************
* Function name: readerGetFlags
* Purpose: Returns the entire flags of Buffer.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Flags from Buffer.
* TO_DO:
*   - Use defensive programming
*   - Check boundary conditions
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_byte readerGetFlags(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Return flags */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return flags
    return readerPointer->flags;
}


/*
***********************************************************
* Function name: readerPrintStat
* Purpose: Shows the char statistic.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value: (Void)
* TO_DO:
*   - Use defensive programming
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_void readerPrintStat(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Print the histogram */
	if (readerPointer == NULL) {
        return;
    }
	 for(int i = 0; i < histogram_size; i++) {  // Assuming HISTOGRAM_SIZE is defined somewhere in your code.
        printf("Value %d: %d\n", i, readerPointer->histogram[i]);
    }
}

/*
***********************************************************
* Function name: readerNumErrors
* Purpose: Returns the number of errors found.
* Parameters:
*   readerPointer = pointer to Buffer Reader
* Return value:
*   Number of errors.
* TO_DO:
*   - Use defensive programming
*   - Adjust for your LANGUAGE.
*************************************************************
*/
SVP_Integer readerNumErrors(ReaderPointer const readerPointer) {
    /* TO_DO: Defensive programming */
    /* TO_DO: Returns the number of errors */
    if (readerPointer == NULL) {
        return -1;
    }

    // Return the number of errors. Please note that the specifics of this operation would depend on your codebase.
    // Assuming readerPointer->errors is a count of errors.
    return readerPointer->numReaderErrors;;
}


