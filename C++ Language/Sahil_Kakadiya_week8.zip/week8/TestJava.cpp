

#include "TestJava.h" // will  include "JNI.h"
#include <iostream>

using namespace std;
static int mean=0;

JNIEXPORT jint JNICALL Java_TestJava_TestCPP(JNIEnv* env, jobject caller, jstring message, jintArray arr )
{
    const char* ch = env->GetStringUTFChars(message,0);
    int len = env->GetArrayLength(arr);
    jint *elements = (env)->GetIntArrayElements(arr,NULL);
    int sum = 0;
    cout << "Hello Java, here is C++. Java sent: " << ch;

    for(int i = 0; i < len; i++)
    {
            sum += elements[i];
    }

    env -> ReleaseStringUTFChars(message, ch);
    env->ReleaseIntArrayElements(arr, elements, 0);
    return sum;
}
JNIEXPORT jdouble JNICALL Java_TestJava_calculateMean(JNIEnv* env, jobject caller, jintArray arr)
{
    
    int len = env->GetArrayLength(arr);
    jint* elements = (env)->GetIntArrayElements(arr, NULL);
    int sum = 0;
   

    for (int i = 0; i < len; i++)
    {
        sum += elements[i];
    }
    jdouble mean = sum / (double)len;
    
    env->ReleaseIntArrayElements(arr, elements, 0);
    return mean;
}
JNIEXPORT jdouble JNICALL Java_TestJava_calculateSTDDev(JNIEnv* env, jobject caller, jintArray arr)
{

    int len = env->GetArrayLength(arr);
    jint* elements = (env)->GetIntArrayElements(arr, NULL);
    int sum = 0;


    for (int i = 0; i < len; i++)
    {
        sum += elements[i];
    }
    jdouble mean = sum / (double)len;
    jdouble sumres = 0;
    for (int i = 0; i < len; i++)
    {
        sumres +=(mean-elements[i])* (mean - elements[i]);
    }
    sumres = sumres / (len + 1);
    sumres = sqrt(sumres);
    env->ReleaseIntArrayElements(arr, elements, 0);
    return sumres;
}