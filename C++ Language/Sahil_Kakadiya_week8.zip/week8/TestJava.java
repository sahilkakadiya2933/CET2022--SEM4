
import java.util.*;
class TestJava
{
   static { System.loadLibrary("MyCPPLibrary"); }

    public static void main(String args[])
    {
        TestJava obj = new TestJava();
        int ret = obj.TestCPP("This is a Java string", new int[] {1, 2, 3, 4, 5});
        System.out.println("C++ added up to:" + ret);
        System.out.print("Enter the number of samples to be generate: ");
        Scanner sc=new Scanner(System.in);
        int numbers=sc.nextInt();
        Random rand=new Random();
        int array[]=new int[numbers];
        for(int i=0;i<array.length;i++)
        {
        	array[i]=rand.nextInt(101);
        }
        double mean= obj.calculateMean(array);
        double STDDDev=obj.calculateSTDDev(array);
       System.out.println(mean);
       System.out.println(STDDDev);
    }
    
   public native double calculateSTDDev( int [] numbers );
    public native double calculateMean(int [] numbers );

    public native int TestCPP(String s, int nums[] );// no method body!

    
}

