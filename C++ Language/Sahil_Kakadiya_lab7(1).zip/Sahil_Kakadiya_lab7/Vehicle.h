#ifndef VEHICLE_H
#define VEHICLE_H

template<class T>
class Vehicle
{

friend T testVehicle(T pVehicle, const char* vehicleName);

public:
    Vehicle(T engineEfficiency, T currentCharge, T maxCharge, T currentGasoline, T maxGasoline);
    ~Vehicle();
    T calculateRange();
    T percentEnergyRemaining();
    void drive(T km);

private:
    T engineEfficiency;
    T currentCharge;
    T maxCharge;
    T currentGasoline;
    T maxGasoline;
};

#include "Vehicle.cpp"

#endif
