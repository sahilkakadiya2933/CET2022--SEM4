#ifndef VEHICLE_CPP
#define VEHICLE_CPP

#include "Vehicle.h"

template<class T>
Vehicle<T>::Vehicle(T engineEfficiency, T currentCharge, T maxCharge, T currentGasoline, T maxGasoline)
    : engineEfficiency(engineEfficiency), currentCharge(currentCharge), maxCharge(maxCharge),
    currentGasoline(currentGasoline), maxGasoline(maxGasoline)
{
}

template<class T>
Vehicle<T>::~Vehicle()
{
}

template<class T>
T Vehicle<T>::calculateRange()
{
    return engineEfficiency * (currentCharge + currentGasoline);
}

template<class T>
T Vehicle<T>::percentEnergyRemaining()
{
    return ((currentCharge + currentGasoline) / (maxCharge + maxGasoline)) * 100;
}

template<class T>
void Vehicle<T>::drive(T km)
{
    T energyRequired = km / engineEfficiency;

    if (currentCharge >= energyRequired)
    {
        currentCharge -= energyRequired;
    }
    else
    {
        T remainingEnergy = energyRequired - currentCharge;
        currentCharge = 0;
        currentGasoline -= remainingEnergy;
    }
}

template<class T>
T testVehicle(T pVehicle, const char* vehicleName)
{
    std::cout << vehicleName << "�s range is: " << pVehicle->calculateRange() << std::endl;
    pVehicle->drive(150); //drive 150 km
    std::cout << vehicleName << "�s energy left is: " << pVehicle->percentEnergyRemaining() << std::endl;
    std::cout << vehicleName << "�s range is now: " << pVehicle->calculateRange() << std::endl;
    return pVehicle;
}

#endif
