#ifndef HELPER_H
#define HELPER_H

#include <algorithm>

namespace Helper
{
    template<class T>
    T min(T a, T b)
    {
        return std::min(a, b);
    }

    template<class T>
    T max(T a, T b)
    {
        return std::max(a, b);
    }
}

#endif
