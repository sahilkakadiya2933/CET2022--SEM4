#ifndef ELECTRIC_VEHICLE_CPP
#define ELECTRIC_VEHICLE_CPP

#include "ElectricVehicle.h"

template<class T>
ElectricVehicle<T>::ElectricVehicle(T currentCharge, T maxCharge)
    : Vehicle<T>(0, currentCharge, maxCharge, 0, 0)
{
}

template<class T>
ElectricVehicle<T>::~ElectricVehicle()
{
}

#endif
