#ifndef HYBRID_VEHICLE_H
#define HYBRID_VEHICLE_H

#include "Vehicle.h"

template<class T>
class HybridVehicle : public Vehicle<T>
{
public:
    HybridVehicle(T currentGasoline, T maxGasoline, T currentCharge, T maxCharge);
    ~HybridVehicle();
};

#include "HybridVehicle.cpp"

#endif
