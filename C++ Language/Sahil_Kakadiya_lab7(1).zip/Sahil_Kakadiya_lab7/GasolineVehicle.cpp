#ifndef GASOLINE_VEHICLE_CPP
#define GASOLINE_VEHICLE_CPP

#include "GasolineVehicle.h"

template<class T>
GasolineVehicle<T>::GasolineVehicle(T currentGasoline, T maxGasoline)
    : Vehicle<T>(0, 0, 0, currentGasoline, maxGasoline)
{
}

template<class T>
GasolineVehicle<T>::~GasolineVehicle()
{
}

#endif
