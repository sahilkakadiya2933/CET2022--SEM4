#ifndef ELECTRIC_VEHICLE_H
#define ELECTRIC_VEHICLE_H

#include "Vehicle.h"

template<class T>
class ElectricVehicle : public Vehicle<T>
{
public:
    ElectricVehicle(T currentCharge, T maxCharge);
    ~ElectricVehicle();
};

#include "ElectricVehicle.cpp"

#endif
