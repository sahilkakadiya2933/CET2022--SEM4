#ifndef HYBRID_VEHICLE_CPP
#define HYBRID_VEHICLE_CPP

#include "HybridVehicle.h"

template<class T>
HybridVehicle<T>::HybridVehicle(T currentGasoline, T maxGasoline, T currentCharge, T maxCharge)
    : Vehicle<T>(0, currentCharge, maxCharge, currentGasoline, maxGasoline)
{
}

template<class T>
HybridVehicle<T>::~HybridVehicle()
{
}

#endif
