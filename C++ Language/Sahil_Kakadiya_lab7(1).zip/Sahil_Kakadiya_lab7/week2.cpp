#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>
#include "Vehicle.h"
#include "GasolineVehicle.h"
#include "ElectricVehicle.h"
#include "HybridVehicle.h"
#include "Helper.h"

void testTemplateLibrary()
{
    std::vector<int> intVector;
    std::srand(static_cast<unsigned int>(std::time(nullptr)));

    for (int i = 0; i < 10; i++)
    {
        int randomNumber = std::rand();
        intVector.push_back(randomNumber);
    }

    for (const auto& number : intVector)
    {
        std::cout << number << " ";
    }
    std::cout << std::endl;
}

int main()
{
    // 50L of gas, 7.1 L/100km
    delete testVehicle(new GasolineVehicle<float>(50.0f, 7.1f), "Corolla");

    // 42 L of gas, 4.3 L/100km, 8.8kWh, 22 kWh/100km
    delete testVehicle(new HybridVehicle<double>(42, 4.3, 8.8, 22.0), "Prius");

    // 75 kWh, 16 kWh/100km
    delete testVehicle(new ElectricVehicle<int>(75, 16), "Tesla 3");

    std::cout << "min of 5 and 7 is:" << Helper::min(5, 7) << std::endl;
    std::cout << "max of 5 and 7 is:" << Helper::max(5, 7) << std::endl;
    std::cout << "min of A and B is:" << Helper::min('A', 'B') << std::endl;
    std::cout << "max of A and B is:" << Helper::max('A', 'B') << std::endl;
    std::cout << "min of string(Hello) and string(world) is:" << Helper::min(std::string("Hello"), std::string("World")) << std::endl;
    std::cout << "max of string(Hello) and string(world) is:" << Helper::max(std::string("Hello"), std::string("World")) << std::endl;

    testTemplateLibrary();

    return 0;
}
