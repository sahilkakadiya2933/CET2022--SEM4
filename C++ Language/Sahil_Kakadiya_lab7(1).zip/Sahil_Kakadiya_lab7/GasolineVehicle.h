#ifndef GASOLINE_VEHICLE_H
#define GASOLINE_VEHICLE_H

#include "Vehicle.h"

template<class T>
class GasolineVehicle : public Vehicle<T>
{
public:
    GasolineVehicle(T currentGasoline, T maxGasoline);
    ~GasolineVehicle();
};

#include "GasolineVehicle.cpp"

#endif
