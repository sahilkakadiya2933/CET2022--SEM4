#include "Vehicle.h"
#include <iostream>

Vehicle::Vehicle() {
    wheels = 0;
    doors = 0;
}

Vehicle::Vehicle(Vehicle& copy) {
    wheels = copy.getWheels();
    doors = copy.getDoors();
}

Vehicle::Vehicle(Vehicle* copy) : Vehicle(*copy) {
    // Copy constructor using pointer
}


int Vehicle::getWheels() const {
    return wheels;
}

void Vehicle::setWheels(int wheels) {
    this->wheels = wheels;
}

int Vehicle::getDoors() const {
    return doors;
}

void Vehicle::setDoors(int doors) {
    this->doors = doors;
}

void Vehicle::printVehicle() {
    std::cout << "Wheels: " << wheels << ", Doors: " << doors << std::endl;
}
