#pragma once

class Vehicle {
private:
    int wheels;
    int doors;

public:
    // Constructors
    Vehicle();
    Vehicle(Vehicle& copy);
    Vehicle(Vehicle* copy);

    // Getters and setters
    int getWheels() const;
    void setWheels(int wheels);
    int getDoors() const;
    void setDoors(int doors);

    // Function declaration
    void printVehicle();
};
