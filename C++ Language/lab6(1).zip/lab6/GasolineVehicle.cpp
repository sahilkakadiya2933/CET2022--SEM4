#include "GasolineVehicle.h"
#include <iostream>

GasolineVehicle::GasolineVehicle(float maxGasoline, float efficiency)
    : currentGasoline(maxGasoline), maximumGasoline(maxGasoline), engineEfficiency(efficiency) {}

GasolineVehicle::~GasolineVehicle() {
    std::cout << "In Gasoline Destructor" << std::endl;
}

float GasolineVehicle::calculateRange() {
    return (currentGasoline * 100) / engineEfficiency;
}

float GasolineVehicle::percentEnergyRemaining() {
    return (currentGasoline / maximumGasoline) * 100.0f;
}

void GasolineVehicle::drive(float km) {
    float range = (currentGasoline * 100) / engineEfficiency;

    if (range >= km) {
        currentGasoline -= (km / 100) * engineEfficiency;
    }
    else {
        std::cout << "Your car is out of energy!" << std::endl;
    }
}
