#ifndef GASOLINE_VEHICLE_H
#define GASOLINE_VEHICLE_H

#include "Vehicle.h"

class GasolineVehicle : public Vehicle {
protected:
    float currentGasoline;
    float maximumGasoline;
    float engineEfficiency;

public:
    GasolineVehicle(float maxGasoline, float efficiency);
    ~GasolineVehicle() override;

    float calculateRange() override;
    float percentEnergyRemaining() override;
    void drive(float km) override;
};

#endif  // GASOLINE_VEHICLE_H
