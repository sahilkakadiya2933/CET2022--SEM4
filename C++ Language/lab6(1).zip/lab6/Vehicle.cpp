#include "Vehicle.h"
#include <iostream>

Vehicle::~Vehicle() {
    std::cout << "In Vehicle Destructor" << std::endl;
}
