#include "ElectricVehicle.h"
#include <iostream>

ElectricVehicle::ElectricVehicle(float maxCharge, float efficiency)
    : currentCharge(maxCharge), maximumCharge(maxCharge), engineEfficiency(efficiency) {}

ElectricVehicle::~ElectricVehicle() {
    std::cout << "In Electric Destructor" << std::endl;
}

float ElectricVehicle::calculateRange() {
    return (currentCharge * 100) / engineEfficiency;
}

float ElectricVehicle::percentEnergyRemaining() {
    return (currentCharge / maximumCharge) * 100.0f;
}

void ElectricVehicle::drive(float km) {
    float range = (currentCharge * 100) / engineEfficiency;

    if (range >= km) {
        currentCharge -= (km / 100) * engineEfficiency;
    }
    else {
        std::cout << "Your car is out of energy!" << std::endl;
    }
}
