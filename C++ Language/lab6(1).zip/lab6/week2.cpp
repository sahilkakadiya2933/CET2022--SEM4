#include "Vehicle.h"
#include "ElectricVehicle.h"
#include "GasolineVehicle.h"
#include "HybridVehicle.h"
#include <iostream>

Vehicle* testVehicle(Vehicle* pVehicle, const char* vehicleName) {
    std::cout << vehicleName << "'s range is: " << pVehicle->calculateRange() << std::endl;
    pVehicle->drive(150.0f); // Drive 150.0 km 
    std::cout << vehicleName << "'s energy left is: " << pVehicle->percentEnergyRemaining() << std::endl;
    std::cout << vehicleName << "'s range is now: " << pVehicle->calculateRange() << std::endl;
    return pVehicle;
}

int main() {
    delete testVehicle(dynamic_cast<GasolineVehicle*>(new HybridVehicle(42.0f, 4.3f, 8.8f, 22.0f)), "Prius");
    delete testVehicle(dynamic_cast<ElectricVehicle*>(new HybridVehicle(42.0f, 4.3f, 8.8f, 22.0f)), "Prius");
    delete testVehicle(new ElectricVehicle(75.0f, 16.0f), "Tesla 3");
    delete testVehicle(new GasolineVehicle(50.0f, 7.1f), "Corolla");
    return 0;
}
