#ifndef VEHICLE_H
#define VEHICLE_H

class Vehicle {
public:
    virtual ~Vehicle();
    virtual float calculateRange() = 0;
    virtual float percentEnergyRemaining() = 0;
    virtual void drive(float km) = 0;
};

#endif  // VEHICLE_H
