#include "HybridVehicle.h"
#include <iostream>

HybridVehicle::HybridVehicle(float maxGasoline, float gasolineEfficiency, float maxCharge, float electricEfficiency)
    : GasolineVehicle(maxGasoline, gasolineEfficiency), ElectricVehicle(maxCharge, electricEfficiency) {}

HybridVehicle::~HybridVehicle() {
    std::cout << "In Hybrid Destructor" << std::endl;
}

float HybridVehicle::calculateRange() {
    float electricRange = (ElectricVehicle::currentCharge * 100) / ElectricVehicle::engineEfficiency;
    float gasolineRange = (GasolineVehicle::currentGasoline * 100) / GasolineVehicle::engineEfficiency;
    return (electricRange + gasolineRange) / 2.0f;
}

float HybridVehicle::percentEnergyRemaining() {
    float electricPercentage = (ElectricVehicle::currentCharge / ElectricVehicle::maximumCharge) * 100.0f;
    float gasolinePercentage = (GasolineVehicle::currentGasoline / GasolineVehicle::maximumGasoline) * 100.0f;
    return (electricPercentage + gasolinePercentage) / 2.0f;
}

void HybridVehicle::drive(float km) {
    float electricRange = (ElectricVehicle::currentCharge * 100) / ElectricVehicle::engineEfficiency;
    float gasolineRange = (GasolineVehicle::currentGasoline * 100) / GasolineVehicle::engineEfficiency;

    if (electricRange >= km) {
        ElectricVehicle::currentCharge -= (km / 100) * ElectricVehicle::engineEfficiency;
    }
    else if (electricRange + gasolineRange >= km) {
        float remainingKm = km - electricRange;
        ElectricVehicle::currentCharge = 0.0f;
        GasolineVehicle::currentGasoline -= (remainingKm / 100) * GasolineVehicle::engineEfficiency;
    }
    else {
        std::cout << "Your car is out of energy!" << std::endl;
    }
}

