#ifndef HYBRID_VEHICLE_H
#define HYBRID_VEHICLE_H

#include "GasolineVehicle.h"
#include "ElectricVehicle.h"

class HybridVehicle : public GasolineVehicle, public ElectricVehicle {
public:
    HybridVehicle(float maxGasoline, float gasolineEfficiency, float maxCharge, float electricEfficiency);
    ~HybridVehicle() override;

    float calculateRange() override;
    float percentEnergyRemaining() override;
    void drive(float km) override;
};

#endif  // HYBRID_VEHICLE_H
