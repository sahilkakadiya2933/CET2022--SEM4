#ifndef ELECTRIC_VEHICLE_H
#define ELECTRIC_VEHICLE_H

#include "Vehicle.h"

class ElectricVehicle : public Vehicle {
protected:
    float currentCharge;
    float maximumCharge;
    float engineEfficiency;

public:
    ElectricVehicle(float maxCharge, float efficiency);
    ~ElectricVehicle() override;

    float calculateRange() override;
    float percentEnergyRemaining() override;
    void drive(float km) override;
};

#endif  // ELECTRIC_VEHICLE_H
