﻿#include<iostream>
using namespace std;
#include "Week3.h"

namespace CST8219 {
    class Vehicle {
    private:
        int numWheels;
        int numDoors;

    public:
        // Constructor a) for the number of wheels and doors
        Vehicle(int w, int d) : numWheels(w), numDoors(d) {
            cout << "In constructor with 2 parameters" << endl;
        }

        // Constructor b) with wheels parameter and calling a)
        Vehicle(int w) : Vehicle(w, 4) {
            cout << "In constructor with 1 parameter, wheels = " << w << endl;
        }

        // Constructor c) empty constructor calling b)
        Vehicle() : Vehicle(4) {
            cout << "In constructor with 0 parameters" << endl;
        }

        ~Vehicle() {
            cout << "Vehicle destroyed." << endl;
        }

    };
}


int main(int argc, char** argv)
{
    using namespace CST8219;
        int d, w;
        char option;
        Vehicle* pVehicle;

        Vehicle veh1;//This calls constructor Vehicle()
        Vehicle veh2(4);//This calls constructor Vehicle(int)
        Vehicle veh3(4, 2);//This calls constructor Vehicle(int,int)
        cout << "Vehicle takes " << sizeof(veh1) << endl;
        cout << "Vehicle takes " << sizeof(veh2) << endl;
        cout << "Vehicle takes " << sizeof(veh3) << endl;

        do{
        while (true) {
            cout << "Enter the amount of door" << endl;
            cin >> d;
            if (cin.fail() || d <= 0) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input, Please enter a positive integer." << endl;
            }
            else {
                break;
            }
        }

        while (true) {
            cout << "Enter the amount of wheels : " << endl;
            cin >> w;
            if (cin.fail() || w <= 0) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input, Please enter a positive integer." << endl;
            }
            else {
                break;
            }

        }

        pVehicle = new Vehicle(w,d);
        cout << "Vehicle takes " << sizeof(pVehicle) << endl;

        cout << "Press any key to create another vehicle or 'q' to quit: \n";
        cin >> option;

        } while (option != 'q');

        return 0;    
}

